
// SECTION 4: OBSTACLES & LLAMAS
const obstacles = [];
const obstacleGeo = new THREE.TorusGeometry(0.7, 0.2, 8, 16);
const obstacleMat = new THREE.MeshStandardMaterial({ color: '#ff0080', emissive: '#ff0080' });

for (let i = 0; i < 40; i++) {
  const obs = new THREE.Mesh(obstacleGeo, obstacleMat);
  obs.position.z = -i * 5;
  obs.position.x = Math.sin(i) * 2;
  obs.position.y = Math.cos(i) * 2;
  scene.add(obs);
  obstacles.push(obs);
}

// LLAMAS
const llamaTexture = new THREE.TextureLoader().load('https://i.imgur.com/BjkYFtE.png');
const llamaMat = new THREE.SpriteMaterial({ map: llamaTexture });
function spawnLlamas() {
  for (let i = 0; i < 5; i++) {
    const llama = new THREE.Sprite(llamaMat);
    llama.position.set(Math.random() * 8 - 4, Math.random() * 6 - 3, -i * 20);
    llama.scale.set(1.5, 1.5, 1.5);
    scene.add(llama);
  }
}
document.addEventListener('keydown', e => { if (e.key === 'l') spawnLlamas(); });
