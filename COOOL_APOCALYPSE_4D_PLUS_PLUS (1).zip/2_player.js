
// SECTION 2: PLAYER SETUP
const players = [];
const colors = ['#00ffff', '#ff9900'];
for (let i = 0; i < 2; i++) {
  const geo = new THREE.IcosahedronGeometry(0.5, 2);
  const mat = new THREE.MeshStandardMaterial({ color: colors[i], emissive: colors[i] });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.x = i === 0 ? -1 : 1;
  scene.add(mesh);
  players.push({ mesh, score: 0 });
}
