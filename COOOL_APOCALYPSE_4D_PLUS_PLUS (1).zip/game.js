
// SECTION 1: INIT & SCENE SETUP
import * as THREE from 'https://cdn.skypack.dev/three@0.150.1';

const canvas = document.querySelector('#game');
const renderer = new THREE.WebGLRenderer({ canvas });
renderer.setSize(window.innerWidth, window.innerHeight);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 1, 5);

const clock = new THREE.Clock();

const ambient = new THREE.AmbientLight(0xffffff, 0.5);
const pointLight = new THREE.PointLight(0xff00ff, 2, 50);
pointLight.position.set(0, 5, 10);
scene.add(ambient, pointLight);


// SECTION 2: PLAYER SETUP
const players = [];
const colors = ['#00ffff', '#ff9900'];
for (let i = 0; i < 2; i++) {
  const geo = new THREE.IcosahedronGeometry(0.5, 2);
  const mat = new THREE.MeshStandardMaterial({ color: colors[i], emissive: colors[i] });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.x = i === 0 ? -1 : 1;
  scene.add(mesh);
  players.push({ mesh, score: 0 });
}


// SECTION 3: CONTROLS
let keys = {};
document.addEventListener('keydown', e => keys[e.key] = true);
document.addEventListener('keyup', e => keys[e.key] = false);

function handleMovement(player, left, right, up, down, delta) {
  if (keys[left]) player.mesh.position.x -= delta * 5;
  if (keys[right]) player.mesh.position.x += delta * 5;
  if (keys[up]) player.mesh.position.y += delta * 5;
  if (keys[down]) player.mesh.position.y -= delta * 5;
  player.mesh.position.z -= delta * 10;
}


// SECTION 4: OBSTACLES & LLAMAS
const obstacles = [];
const obstacleGeo = new THREE.TorusGeometry(0.7, 0.2, 8, 16);
const obstacleMat = new THREE.MeshStandardMaterial({ color: '#ff0080', emissive: '#ff0080' });

for (let i = 0; i < 40; i++) {
  const obs = new THREE.Mesh(obstacleGeo, obstacleMat);
  obs.position.z = -i * 5;
  obs.position.x = Math.sin(i) * 2;
  obs.position.y = Math.cos(i) * 2;
  scene.add(obs);
  obstacles.push(obs);
}

// LLAMAS
const llamaTexture = new THREE.TextureLoader().load('https://i.imgur.com/BjkYFtE.png');
const llamaMat = new THREE.SpriteMaterial({ map: llamaTexture });
function spawnLlamas() {
  for (let i = 0; i < 5; i++) {
    const llama = new THREE.Sprite(llamaMat);
    llama.position.set(Math.random() * 8 - 4, Math.random() * 6 - 3, -i * 20);
    llama.scale.set(1.5, 1.5, 1.5);
    scene.add(llama);
  }
}
document.addEventListener('keydown', e => { if (e.key === 'l') spawnLlamas(); });


// SECTION 5: SCORE + ANIMATION
const score1El = document.getElementById('score1');
const score2El = document.getElementById('score2');

function animate() {
  requestAnimationFrame(animate);
  const delta = clock.getDelta();

  handleMovement(players[0], 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', delta);
  handleMovement(players[1], 'a', 'd', 'w', 's', delta);

  for (const obs of obstacles) {
    players.forEach((p, index) => {
      if (obs.position.distanceTo(p.mesh.position) < 1) {
        p.score = 0;
        p.mesh.position.set(index === 0 ? -1 : 1, 0, 0);
      }
    });
  }

  players[0].score += delta * 10;
  players[1].score += delta * 10;
  score1El.textContent = Math.floor(players[0].score);
  score2El.textContent = Math.floor(players[1].score);

  camera.position.z = players[0].mesh.position.z + 5;
  renderer.render(scene, camera);
}
animate();
