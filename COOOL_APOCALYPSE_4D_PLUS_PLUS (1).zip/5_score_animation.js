
// SECTION 5: SCORE + ANIMATION
const score1El = document.getElementById('score1');
const score2El = document.getElementById('score2');

function animate() {
  requestAnimationFrame(animate);
  const delta = clock.getDelta();

  handleMovement(players[0], 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', delta);
  handleMovement(players[1], 'a', 'd', 'w', 's', delta);

  for (const obs of obstacles) {
    players.forEach((p, index) => {
      if (obs.position.distanceTo(p.mesh.position) < 1) {
        p.score = 0;
        p.mesh.position.set(index === 0 ? -1 : 1, 0, 0);
      }
    });
  }

  players[0].score += delta * 10;
  players[1].score += delta * 10;
  score1El.textContent = Math.floor(players[0].score);
  score2El.textContent = Math.floor(players[1].score);

  camera.position.z = players[0].mesh.position.z + 5;
  renderer.render(scene, camera);
}
animate();
