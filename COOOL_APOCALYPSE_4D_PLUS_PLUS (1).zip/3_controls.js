
// SECTION 3: CONTROLS
let keys = {};
document.addEventListener('keydown', e => keys[e.key] = true);
document.addEventListener('keyup', e => keys[e.key] = false);

function handleMovement(player, left, right, up, down, delta) {
  if (keys[left]) player.mesh.position.x -= delta * 5;
  if (keys[right]) player.mesh.position.x += delta * 5;
  if (keys[up]) player.mesh.position.y += delta * 5;
  if (keys[down]) player.mesh.position.y -= delta * 5;
  player.mesh.position.z -= delta * 10;
}
