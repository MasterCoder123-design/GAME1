
// SECTION 1: INIT & SCENE SETUP
import * as THREE from 'https://cdn.skypack.dev/three@0.150.1';

const canvas = document.querySelector('#game');
const renderer = new THREE.WebGLRenderer({ canvas });
renderer.setSize(window.innerWidth, window.innerHeight);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 1, 5);

const clock = new THREE.Clock();

const ambient = new THREE.AmbientLight(0xffffff, 0.5);
const pointLight = new THREE.PointLight(0xff00ff, 2, 50);
pointLight.position.set(0, 5, 10);
scene.add(ambient, pointLight);
